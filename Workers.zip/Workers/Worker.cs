﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workers
{
    public class Worker
    {
        public string FullName { get; set; }
        public string BirthDate { get; set; }
        public string INN { get; set; }
        public string Passport { get; set; }
        public string Phone { get; set; }
        public string Gender { get; set; }
        public string Age { get; set; }
    }
}
